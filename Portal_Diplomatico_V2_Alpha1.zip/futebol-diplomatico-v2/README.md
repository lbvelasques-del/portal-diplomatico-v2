# Portal Diplomático v2 — primeira entrega técnica

Nova base do **Futebol Diplomático** (jogo principal) + lobby do **Cassino Diplomático** (passatempo). Esta entrega é um **MVP Alpha**, não um site pronto para colocar apostas em produção.

## O que funciona nesta etapa

- Portal responsivo para celular com navegação, dashboard e lobby do cassino.
- **Modo de demonstração offline:** inicia sem configurar Supabase, permite selecionar um dos 20 clubes fictícios, gerir elenco de 23 atletas, testar as 16 formações e simular uma partida **local**.
- Formação de 11 titulares, troca de atletas por posição, encaixe posicional, classes Bronze/Prata/Ouro/Diamante e painel de técnico (estilo, mentalidade, pressão e ritmo).
- Tabela de campeonato calculada a partir dos resultados.
- **Modo online opcional:** Supabase Auth (e-mail/senha), contratos de técnico e jogador por temporada, escalação salva no servidor, jogos simulados por RPC, placares oficiais do campeonato e carteiras de créditos de teste.
- Painel de administrador: criar partidas, simulá-las e ajustar **créditos de teste** com histórico/auditoria.
- Minijogo de dados gratuito no cassino. Outros jogos estão listados para migração posterior, **sem apostas neste Alpha**.

## O que ainda NÃO está pronto

- Escudos, nomes e escalações oficiais da Série A. Os 20 clubes e 460 atletas incluídos são **fictícios** e marcados como demonstração. Dados oficiais exigem fonte/licença e validação por temporada.
- Transferências, leilão, evolução física, lesões, substituições, rodadas automáticas, notificações e temporadas subsequentes.
- Integração ou resgate de moeda de outro jogo; créditos nesta versão não são dinheiro, não são conversíveis e não são apostados.
- Os oito minijogos antigos ainda precisam ser migrados e revisados. O motor dos novos jogos não deve modificar `wallets` via cliente.
- Testes integrados em um projeto Supabase real / deployment e auditoria de segurança externa. Não declaramos este Alpha pronto para produção.

## 1. Testar agora sem banco de dados

1. Descompacte esta pasta e abra um terminal dentro dela.
2. Instale Node.js 20+.
3. Rode `npm install`.
4. Rode `npm run dev`.
5. Acesse o endereço mostrado pelo Vite. Sem arquivo `.env`, a página inicia no **Modo demonstração**. As escolhas ficam só no navegador.

## 2. Ativar multiplayer online

**Atenção: crie um projeto Supabase novo, separado da versão antiga,** pois o código antigo inclui autenticação insegura e registros de saldos não confiáveis.

1. Crie um projeto no Supabase.
2. Abra **SQL Editor**, cole e execute **uma vez** o conteúdo de `supabase/migrations/001_portal_diplomatico.sql`. Ele cria tabelas, políticas RLS, funções de servidor, uma temporada e o conteúdo fictício de teste.
3. Em **Authentication**, habilite o provedor de e-mail e configure a confirmação de e-mail e URLs permitidas conforme seu domínio.
4. Copie `.env.example` para `.env` e preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY` com os valores públicos de **Project Settings > API**. **Nunca use `service_role` no frontend.**
5. Rode `npm run dev` (ou reinicie o Vite). Agora deve aparecer **ONLINE** e será necessário cadastrar uma conta.
6. Após criar a sua conta, conceda o papel de administrador **somente no SQL Editor**, substituindo o e-mail abaixo pelo seu:

```sql
update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = 'seu@email.com');
```

7. Crie ao menos **duas contas** em navegadores diferentes. Cada conta deve escolher **um clube distinto** e salvar os 11 jogadores. Em seguida, na conta administradora, crie e simule uma partida.
8. Os resultados são registrados no banco, e o campeonato passa a ser compartilhado. O frontend atual atualiza os dados periodicamente (aproximadamente a cada 20 segundos).

## 3. Publicar a nova versão sem perder a antiga

- Guarde o repositório antigo como backup ou preserve a branch `main` até validar o novo projeto.
- Suba os arquivos **descompactados** em uma nova branch ou um novo repositório.
- Configure no serviço de hospedagem (Vercel, Netlify etc.) as duas variáveis `VITE_SUPABASE_*`.
- Comando de build: `npm run build`; diretório gerado: `dist`.
- Consulte os requisitos legais e a política do jogo Diplomacia antes de operar qualquer sistema que receba moedas de origem externa, ofereça prêmios com valor ou permita resgate/troca.

**Importante:** A conexão GitHub disponível nesta sessão possui permissão de **leitura**, não de escrita. Nenhum arquivo foi alterado no repositório existente.

## Arquitetura

```
index.html
src/
  App.jsx                    Portal, login, lobby, cassino e painel admin
  main.jsx                   Inicialização React
  styles.css                 Layout responsivo
  components/Football.jsx    Manager, formações, escalação, tabela
  lib/formations.js          16 formações, classes e montagem do XI
  lib/demo.js                20 clubes fictícios, 460 atletas, teste local
  lib/supabase.js            Conexão por variáveis de ambiente
supabase/migrations/
  001_portal_diplomatico.sql Esquema, RLS, contratos e RPCs de servidor
```

## Segurança

- O frontend nunca recebe senha de outra pessoa e não define administrador pelo nome de usuário.
- Tabelas de carteira, partidas e contratos têm RLS; o cliente só lê o que lhe é autorizado.
- Ajustes de carteira, assinatura de clube, salvamento de tática e simulação oficial são funções SQL autenticadas com verificação de autorização.
- A simulação de futebol contém aleatoriedade: força e adequação tática elevam a chance de vencer, sem garantir vitória.
- O modo offline é **apenas demonstrativo**, sem proteção contra adulteração e sem sincronização entre amigos.
- Antes de produção: executar revisão de segurança, testes de concorrência, acessibilidade, logs, recuperação de dados e políticas de privacidade.
