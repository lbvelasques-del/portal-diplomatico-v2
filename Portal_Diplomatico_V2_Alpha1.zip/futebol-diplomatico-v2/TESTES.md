# Checklist de aceitação — Alpha 1

## Ambiente sem Supabase
- [ ] Portal abre sem login mostrando `TESTE LOCAL`.
- [ ] Escolher um dos 20 clubes funciona.
- [ ] Escalação inicial seleciona 11 atletas distintos.
- [ ] Trocar entre as 16 formações gera 11 espaços.
- [ ] Selecionar outro atleta não permite repetição no XI.
- [ ] Salvar a formação e recarregar mantém a escolha no navegador.
- [ ] Testar partida gera placar e altera a classificação local.
- [ ] Minijogo Diplomatic Dice funciona sem gastar créditos.
- [ ] Página é utilizável num celular sem cortes horizontais.

## Ambiente Supabase (obrigatório antes do multiplayer)
- [ ] Cadastro exige e-mail, senha e confirmação segundo configuração.
- [ ] Dois usuários em dispositivos diferentes são contas independentes.
- [ ] Um clube não pode ser escolhido por dois usuários na mesma temporada.
- [ ] Um usuário não pode contratar dois clubes na mesma temporada.
- [ ] Apenas o técnico de um clube consegue salvar a sua tática.
- [ ] Não é possível escalar jogador de outro clube ou duplicar um jogador.
- [ ] O frontend não pode atualizar diretamente carteira, contratos ou partidas.
- [ ] Usuário comum não consegue chamar funções de administração.
- [ ] Simular partida simultaneamente em duas sessões não registra dois resultados.
- [ ] Partida exige tática válida de ambos os treinadores.
- [ ] A classificação soma corretamente três pontos por vitória e um por empate.
- [ ] Ajustes de crédito geram registro de auditoria.
- [ ] A interface atualiza após partidas registradas em outra sessão.

## Antes da estreia oficial
- [ ] Importar e revisar plantéis e clubes reais com fonte/autorização.
- [ ] Aprovação de regulamento e calendário de rodadas.
- [ ] Definição da moeda exclusivamente recreativa e análise jurídica.
- [ ] Revisão do motor esportivo e testes estatísticos de equilíbrio.
- [ ] Backup e política de restauração.
- [ ] Auditoria independente e testes com vários usuários.
