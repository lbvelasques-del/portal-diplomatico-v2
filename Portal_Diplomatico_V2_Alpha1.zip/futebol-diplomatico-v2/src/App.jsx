import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, ArrowRight, Banknote, CalendarDays, CheckCircle2, ChevronRight, CircleHelp, Coins, Crown, Dices, Gamepad2, LayoutDashboard, Lock, LogOut, Menu, Play, RefreshCw, Shield, ShieldCheck, Sparkles, Trophy, UserRound, Users, Wallet, X } from 'lucide-react';
import { supabase, isDemo } from './lib/supabase.js';
import { DEMO_SEASON_ID, demoClubs, demoPlayers, demoSimulateMatch, demoStandings, getDemoState, getDemoTactic, setDemoState } from './lib/demo.js';
import Football, { ClubMark, SmallPill } from './components/Football.jsx';

const INITIAL = {profile:null,wallet:null,season:null,clubs:[],players:[],contract:null,occupied:[],tactic:null,matches:[],standings:[]};
const DEMO_PROFILE={id:'demo-user',display_name:'Treinador convidado',role:'player'};
const formatCredits=n=>new Intl.NumberFormat('pt-BR').format(Number(n)||0);
const games=[
  {id:'dice',name:'Diplomatic Dice',icon:'🎲',desc:'Adivinhe o resultado do dado.',ready:true},
  {id:'slots',name:'Caça-níqueis',icon:'🎰',desc:'Módulo antigo aguardando migração segura.'},
  {id:'crash',name:'Pampas Crash',icon:'🚀',desc:'Módulo antigo aguardando migração segura.'},
  {id:'roulette',name:'Roleta Diplomática',icon:'🎡',desc:'Módulo antigo aguardando migração segura.'},
  {id:'hilo',name:'Pampas HiLo',icon:'🃏',desc:'Módulo antigo aguardando migração segura.'},
  {id:'goal',name:'Pampas Goal',icon:'🥅',desc:'Módulo antigo aguardando migração segura.'},
  {id:'towers',name:'Pampas Towers',icon:'🏯',desc:'Módulo antigo aguardando migração segura.'},
  {id:'diamond',name:'Diamond Striker',icon:'💎',desc:'Módulo antigo aguardando migração segura.'}
];

function App() {
  const [user,setUser]=useState(isDemo?{id:'demo-user'}:null);
  const [view,setView]=useState('home');
  const [data,setData]=useState(INITIAL);
  const [loading,setLoading]=useState(!isDemo);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState('');
  const [authMode,setAuthMode]=useState('login');
  const [authFields,setAuthFields]=useState({name:'',email:'',password:''});
  const [mobileMenu,setMobileMenu]=useState(false);

  const inform=(msg)=>{setNotice(msg);window.scrollTo?.({top:0,behavior:'smooth'});};

  const load=useCallback(async()=>{
    if(isDemo){
      const state=getDemoState();
      const club=state.clubId;
      setData({profile:DEMO_PROFILE,wallet:{balance:0},season:{id:DEMO_SEASON_ID,name:'Temporada de testes',status:'open'},
        clubs:demoClubs,players:demoPlayers,contract:club?{club_id:club}:null,
        occupied:club?[club]:[],tactic:club?getDemoTactic(club):null,
        matches:state.matches,standings:demoStandings(state.matches)});
      setLoading(false);return;
    }
    if(!user){setData(INITIAL);setLoading(false);return;}
    try {
      const [p,w,s,c]=await Promise.all([
        supabase.from('profiles').select('id,display_name,role').eq('id',user.id).single(),
        supabase.from('wallets').select('balance').eq('user_id',user.id).single(),
        supabase.from('seasons').select('*').in('status',['open','active']).order('created_at',{ascending:false}).limit(1).maybeSingle(),
        supabase.from('clubs').select('*').order('name')
      ]);
      for(const x of [p,w,s,c]) if(x.error) throw x.error;
      const season=s.data;
      if(!season){setData({...INITIAL,profile:p.data,wallet:w.data,clubs:c.data||[]});setLoading(false);return;}
      const [mc,pc,ma,st]=await Promise.all([
        supabase.from('manager_contracts').select('club_id,user_id').eq('season_id',season.id),
        supabase.from('player_contracts').select('club_id,player:players(id,name,position,overall,tier,shirt_number)').eq('season_id',season.id),
        supabase.from('matches').select('*').eq('season_id',season.id).order('created_at',{ascending:false}).limit(60),
        supabase.from('standings').select('*').eq('season_id',season.id)
      ]);
      for(const x of [mc,pc,ma,st]) if(x.error) throw x.error;
      const contract=(mc.data||[]).find(x=>x.user_id===user.id)||null;
      let tactics=null;
      if(contract){const t=await supabase.from('team_tactics').select('*').eq('season_id',season.id).eq('club_id',contract.club_id).maybeSingle();if(t.error)throw t.error;tactics=t.data;}
      setData({profile:p.data,wallet:w.data,season,clubs:c.data||[],players:(pc.data||[]).filter(x=>x.player).map(x=>({...x.player,club_id:x.club_id})),
        contract,occupied:(mc.data||[]).map(x=>x.club_id),tactic:tactics,matches:ma.data||[],
        standings:(st.data||[]).sort((a,b)=>b.points-a.points||b.wins-a.wins||b.goal_diff-a.goal_diff||b.goals_for-a.goals_for)});
    }catch(err){inform(`Erro ao carregar: ${err.message||'verifique a configuração do Supabase'}`);}
    finally{setLoading(false);}
  },[user?.id]);

  useEffect(()=>{
    if(isDemo)return;
    let active=true;
    supabase.auth.getSession().then(({data:{session},error})=>{if(active){if(error)inform(error.message);setUser(session?.user||null);setLoading(false);}});
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_ev,s)=>{if(active)setUser(s?.user||null);});
    return()=>{active=false;subscription.unsubscribe();};
  },[]);
  useEffect(()=>{load();},[load]);
  useEffect(()=>{if(isDemo||!user)return;const timer=setInterval(()=>load(),20000);return()=>clearInterval(timer);},[load,user?.id]);
  useEffect(()=>{if(!notice)return;const timeout=setTimeout(()=>setNotice(''),7000);return()=>clearTimeout(timeout);},[notice]);

  async function submitAuth(e){e.preventDefault();setBusy(true);setNotice('');
    try{
      if(authMode==='register'){
        if(authFields.password.length<8)throw new Error('Use uma senha com pelo menos 8 caracteres.');
        const {data:result,error}=await supabase.auth.signUp({email:authFields.email.trim(),password:authFields.password,
          options:{data:{display_name:authFields.name.trim().slice(0,36)}}});
        if(error)throw error;
        inform(result.session?'Conta criada com sucesso.':'Cadastro recebido. Confira seu e-mail para confirmar a conta.');
      }else{
        const {error}=await supabase.auth.signInWithPassword({email:authFields.email.trim(),password:authFields.password});
        if(error)throw error;
        inform('Bem-vindo ao Portal Diplomático.');
      }
    }catch(err){inform(err.message||'Falha na autenticação.');}finally{setBusy(false);}
  }
  async function signOut(){if(!isDemo)await supabase.auth.signOut();setView('home');}
  async function perform(fn){setBusy(true);setNotice('');try{const message=await fn();if(message)inform(message);await load();}catch(err){inform(err.message||'Não foi possível concluir a ação.');}finally{setBusy(false);}}
  function claimClub(id){perform(async()=>{if(isDemo){const state=getDemoState();if(state.clubId)throw new Error('Você já escolheu um clube.');setDemoState({...state,clubId:id});return 'Clube selecionado. Agora monte sua escalação!';}
    const {error}=await supabase.rpc('claim_club',{p_season_id:data.season.id,p_club_id:id});if(error)throw error;
    return 'Contrato de treinador confirmado para a temporada.';});}
  function saveTactic(t){perform(async()=>{if(isDemo){const state=getDemoState();setDemoState({...state,tactics:{...state.tactics,[state.clubId]:{...t,isDraft:false,updated_at:new Date().toISOString()}}});return 'Escalação gravada neste navegador (demonstração).';}
    const {error}=await supabase.rpc('save_tactics',{p_season_id:data.season.id,p_formation:t.formation,p_style:t.style,
      p_mentality:t.mentality,p_pressure:t.pressure,p_tempo:t.tempo,p_lineup:t.lineup});if(error)throw error;
    return 'Sua escalação foi salva no servidor.';});}
  function simulateDemo(){perform(async()=>{const st=getDemoState();const opponent=demoClubs.find(c=>c.id!==st.clubId&&c.id!==st.matches.at(-1)?.away_club_id)||demoClubs.find(c=>c.id!==st.clubId);
    if(!opponent)throw new Error('Nenhum adversário encontrado.');
    const m=demoSimulateMatch(st.clubId,opponent.id,getDemoTactic(st.clubId),getDemoTactic(opponent.id));
    setDemoState({...st,matches:[m,...st.matches]});return `Jogo de teste: ${m.home_goals} x ${m.away_goals}. Resultado apenas local.`;});}
  const myClubId=data.contract?.club_id;
  const myClub=data.clubs.find(x=>x.id===myClubId);
  const isAdmin=data.profile?.role==='admin';
  const nav=[{id:'home',label:'Início',Icon:LayoutDashboard},{id:'football',label:'Futebol',Icon:Trophy},{id:'casino',label:'Cassino',Icon:Dices},{id:'account',label:'Conta',Icon:UserRound}];
  if(isAdmin)nav.push({id:'admin',label:'Admin',Icon:ShieldCheck});
  const go=id=>{setView(id);setMobileMenu(false);window.scrollTo?.({top:0});};

  return <div className="app-shell">
    <header className="topbar"><div className="topbar-inner"><button className="brand" onClick={()=>go('home')}><span className="brand-symbol"><Shield size={19}/></span><span>PORTAL <b>DIPLOMÁTICO</b><small>ESTAÇÃO DE JOGOS</small></span></button>
      <div className="topbar-right"><span className={`mode-pill ${isDemo?'test':''}`}>{isDemo?'TESTE LOCAL':'ONLINE'}</span>{user&&<div className="balance-chip"><Coins size={17}/><div><span>CARTEIRA</span><strong>{formatCredits(data.wallet?.balance)} CR</strong></div></div>}
      <button className="mobile-menu-btn" onClick={()=>setMobileMenu(!mobileMenu)} aria-label="Abrir menu">{mobileMenu?<X size={21}/>:<Menu size={21}/>}</button></div></div></header>
    {notice&&<div className="toast"><CircleHelp size={18}/>{notice}<button onClick={()=>setNotice('')} aria-label="Fechar"><X size={16}/></button></div>}
    {!user&&!isDemo ? <main className="auth-layout"><div className="auth-intro"><div className="eyebrow"><Trophy size={14}/> ESTÁ NA HORA DO JOGO</div><h1>A sua próxima temporada começa aqui.</h1><p>Gerencie um clube, dispute campeonatos com seus amigos e aproveite minijogos recreativos no mesmo portal.</p><div className="auth-features"><span><ShieldCheck size={17}/> Conta individual segura</span><span><Users size={17}/> Multiplayer online</span><span><Activity size={17}/> Estratégia de verdade</span></div></div>
       <form className="auth-card" onSubmit={submitAuth}><div className="eyebrow">ACESSO À PLATAFORMA</div><h2>{authMode==='login'?'Entre na sua conta':'Crie sua conta'}</h2>{authMode==='register'&&<label>Nome de treinador<input required maxLength={36} value={authFields.name} onChange={e=>setAuthFields(x=>({...x,name:e.target.value}))} placeholder="Como você quer ser chamado"/></label>}<label>E-mail<input type="email" required value={authFields.email} onChange={e=>setAuthFields(x=>({...x,email:e.target.value}))} placeholder="email@exemplo.com"/></label><label>Senha<input type="password" minLength={8} required value={authFields.password} onChange={e=>setAuthFields(x=>({...x,password:e.target.value}))} placeholder="Mínimo de 8 caracteres"/></label><button className="primary-btn" disabled={busy} type="submit">{busy?'Enviando...':authMode==='login'?'Entrar no portal':'Criar minha conta'} <ArrowRight size={16}/></button><button type="button" className="text-button" onClick={()=>setAuthMode(authMode==='login'?'register':'login')}>{authMode==='login'?'Não tenho conta. Quero me cadastrar.':'Já tenho conta. Fazer login.'}</button></form></main>
    : <div className="content-layout"><aside className={`sidebar ${mobileMenu?'mobile-open':''}`}><div className="sidebar-caption">NAVEGAÇÃO</div>{nav.map(({id,label,Icon})=><button key={id} className={`nav-item ${view===id?'selected':''}`} onClick={()=>go(id)}><Icon size={19}/>{label}<ChevronRight size={15} className="nav-arrow"/></button>)}<div className="sidebar-bottom"><div className="sidebar-help"><Sparkles size={16}/><strong>Temporada Alpha</strong><p>Estamos construindo o primeiro campeonato.</p></div><span className="small muted">v2.0 • estrutura renovada</span></div></aside>
      <main className="main-content">{loading?<div className="loading-screen"><RefreshCw className="spin"/> Carregando...</div>:
        view==='home'?<Home data={data} myClub={myClub} go={go} isDemo={isDemo}/>:
        view==='football'?<Football clubs={data.clubs} players={data.players} matches={data.matches} standings={data.standings} season={data.season} myClubId={myClubId} occupied={data.occupied} tactic={data.tactic} onClaim={claimClub} onSave={saveTactic} onSimulate={simulateDemo} busy={busy} isDemo={isDemo}/>:
        view==='casino'?<Casino/>:
        view==='account'?<Account profile={data.profile} wallet={data.wallet} user={user} isDemo={isDemo} signOut={signOut}/>:
        view==='admin'&&isAdmin?<Admin data={data} busy={busy} run={perform} reload={load}/>:
        <Home data={data} myClub={myClub} go={go} isDemo={isDemo}/>}
      </main></div>}
    {user&&<nav className="bottom-nav">{nav.filter(x=>x.id!=='admin').map(({id,label,Icon})=><button key={id} className={view===id?'active':''} onClick={()=>go(id)}><Icon size={19}/><span>{label}</span></button>)}</nav>}
  </div>;
}
function Home({data,myClub,go,isDemo}) {
  return <div className="page-in"><div className="page-heading"><div><div className="eyebrow"><Sparkles size={13}/> BEM-VINDO AO PORTAL</div><h1>Seu centro de <em>comando.</em></h1><p>Uma conta. Um clube. Uma temporada para fazer história.</p></div></div>
    <div className="dashboard-hero"><div className="hero-copy"><span className="hero-kicker"><span className="green-dot"/> FUTEBOL DIPLOMÁTICO</span><h2>O campo é seu.<br/><em>A estratégia também.</em></h2><p>Monte seu time, dispute cada rodada e conquiste o topo da classificação com decisões inteligentes.</p><button className="primary-btn" onClick={()=>go('football')}>{myClub?'Gerenciar meu clube':'Escolher meu clube'} <ArrowRight size={17}/></button></div><div className="hero-visual"><div className="orb"/><Trophy size={100} strokeWidth={1.25}/><span>SEASON <b>01</b></span></div></div>
    <div className="stat-grid"><div className="stat-card"><span>Clubes da liga</span><strong>{data.clubs.length}</strong><small>Um por treinador</small></div><div className="stat-card"><span>Treinadores confirmados</span><strong>{data.occupied.length}</strong><small>Contratos de uma temporada</small></div><div className="stat-card"><span>Jogos registrados</span><strong>{data.matches.filter(x=>x.status==='played').length}</strong><small>Campeonato em andamento</small></div></div>
    <div className="section-heading"><h3>Explore a plataforma</h3><SmallPill>{isDemo?'Experiência de teste':'Multiplayer conectado'}</SmallPill></div>
    <div className="feature-grid"><button className="feature-card football-feature" onClick={()=>go('football')}><div className="feature-icon"><Trophy size={27}/></div><span>JOGO PRINCIPAL</span><h3>Futebol Diplomático</h3><p>{myClub?`Seu clube: ${myClub.name}. Prepare seu próximo jogo.`:'Escolha entre 20 clubes e assuma o comando.'}</p><div className="feature-action">Entrar no manager <ArrowRight size={16}/></div></button><button className="feature-card casino-feature" onClick={()=>go('casino')}><div className="feature-icon"><Dices size={27}/></div><span>ÁREA DE PASSATEMPO</span><h3>Cassino Diplomático</h3><p>Um espaço para minijogos recreativos enquanto você espera a próxima rodada.</p><div className="feature-action">Explorar minijogos <ArrowRight size={16}/></div></button></div>
    <div className="demo-note"><ShieldCheck size={18}/><div>{isDemo?'Esta é uma demonstração local; escolhas e resultados não aparecem para os seus amigos.':'O portal usa autenticação e um banco compartilhado. Créditos são unidades de teste sem conversão ou resgate.'}</div></div>
  </div>;
}
function Casino() {
  const [dice,setDice]=useState(null);const [guess,setGuess]=useState('maior');const [result,setResult]=useState('');
  function playDice(){const n=Math.floor(Math.random()*6)+1;setDice(n);const won=guess==='maior'?n>=4:n<=3;setResult(won?'Você acertou!':'Não foi desta vez.');}
  return <div className="page-in"><div className="page-heading"><div><div className="eyebrow"><Dices size={13}/> LOBBY DE PASSATEMPO</div><h1>Cassino <em>Diplomático</em></h1><p>Minijogos recreativos em um espaço separado do manager.</p></div><SmallPill tone="warn">EM RECONSTRUÇÃO</SmallPill></div>
   <div className="casino-banner"><div><h2>Entre uma rodada e outra, jogue.</h2><p>Os jogos antigos serão migrados um por um. Até que a carteira esteja auditada, esta área não movimenta créditos.</p></div><Dices size={64}/></div>
   <div className="mini-game-grid">{games.map(g=><div key={g.id} className={`mini-game-card ${g.ready?'ready':''}`}><div className="mini-icon">{g.icon}</div><h3>{g.name}</h3><p>{g.desc}</p><SmallPill tone={g.ready?'good':'warn'}>{g.ready?'Jogável (sem aposta)':'Em migração'}</SmallPill></div>)}</div>
   <section className="surface dice-demo"><div className="section-heading"><h3><Dices size={18}/> Diplomatic Dice • treino</h3><SmallPill tone="good">SEM APOSTAS</SmallPill></div><p>Escolha se o número será de 1 a 3 ou de 4 a 6. Cada rodada é gratuita.</p><div className="dice-display">{dice??'?'}</div><div className="dice-controls"><button className={guess==='menor'?'selected':''} onClick={()=>setGuess('menor')}>1 a 3</button><button className={guess==='maior'?'selected':''} onClick={()=>setGuess('maior')}>4 a 6</button></div><button className="primary-btn" onClick={playDice}><Play size={17}/> Rolar dado</button>{result&&<p className="game-feedback">Saiu {dice}. {result}</p>}</section>
  </div>;
}
function Account({profile,wallet,user,isDemo,signOut}) {
  const [history,setHistory]=useState([]);
  useEffect(()=>{if(isDemo||!user)return;let active=true;supabase.from('wallet_transactions')
    .select('id,amount,balance_after,reason,created_at').eq('user_id',user.id)
    .order('created_at',{ascending:false}).limit(10).then(({data})=>{if(active)setHistory(data||[]);});
    return()=>{active=false;};},[user?.id,isDemo]);
  return <div className="page-in"><div className="page-heading"><div><div className="eyebrow"><UserRound size={13}/> PERFIL DO TREINADOR</div><h1>Minha <em>conta.</em></h1><p>Informações de acesso e carteira interna.</p></div></div>
   <section className="surface account-panel"><div className="account-avatar"><UserRound size={35}/></div><div><h2>{profile?.display_name||'Treinador'}</h2><p className="muted">{isDemo?'Conta local de demonstração':user?.email}</p><SmallPill tone={profile?.role==='admin'?'gold':'good'}>{profile?.role==='admin'?'Administrador':'Treinador'}</SmallPill></div></section>
   <div className="two-col"><section className="surface"><div className="section-heading"><h3><Wallet size={18}/> Saldo interno</h3></div><div className="wallet-number">{formatCredits(wallet?.balance)} <small>CR</small></div><p>Créditos virtuais de teste. Sem valor monetário e sem resgate nesta versão.</p></section><section className="surface"><div className="section-heading"><h3><Lock size={18}/> Segurança</h3></div><p>{isDemo?'Modo offline: não há autenticação ou sincronização neste ambiente.':'As senhas são gerenciadas pelo Supabase Auth, não ficam em tabelas acessíveis do aplicativo.'}</p>{!isDemo&&<button className="outline-btn" onClick={signOut}><LogOut size={16}/> Sair da conta</button>}</section></div>
   {!isDemo&&<section className="surface"><div className="section-heading"><h3><Activity size={18}/> Extrato de créditos</h3></div>{history.length?history.map(tx=><div className="pending-row" key={tx.id}><span>{tx.reason}<small className="muted" style={{display:'block'}}>{new Date(tx.created_at).toLocaleDateString('pt-BR')} • Saldo após: {formatCredits(tx.balance_after)} CR</small></span><strong style={{color:tx.amount>0?'#72e0a6':'#f3a6a6'}}>{tx.amount>0?'+':''}{formatCredits(tx.amount)} CR</strong></div>):<p className="muted">Sem movimentações registradas.</p>}</section>}
  </div>;
}
function Admin({data,busy,run,reload}) {
  const [amount,setAmount]=useState('');const [userId,setUserId]=useState('');const [reason,setReason]=useState('Crédito de teste');
  const [home,setHome]=useState('');const [away,setAway]=useState('');
  const [accounts,setAccounts]=useState([]);
  useEffect(()=>{let active=true;supabase.from('profiles').select('id,display_name').order('display_name')
    .then(({data})=>{if(active)setAccounts(data||[]);});return()=>{active=false;};},[]);
  async function adjust(e){e.preventDefault();await run(async()=>{const n=Number(amount);if(!Number.isSafeInteger(n)||n===0)throw new Error('Digite uma quantidade inteira diferente de zero.');
    const {error}=await supabase.rpc('admin_adjust_balance',{p_target_user:userId,p_delta:n,p_reason:reason});if(error)throw error;setAmount('');return 'Transação registrada em livro de movimentos.';});}
  async function schedule(e){e.preventDefault();await run(async()=>{if(home===away)throw new Error('Escolha clubes diferentes.');const {error}=await supabase.rpc('admin_schedule_match',{p_season_id:data.season.id,p_home_club:home,p_away_club:away});if(error)throw error;return 'Partida agendada.';});}
  async function simulate(id){await run(async()=>{const {error}=await supabase.rpc('admin_simulate_match',{p_match_id:id});if(error)throw error;return 'Partida processada com resultado registrado no servidor.';});}
  return <div className="page-in"><div className="page-heading"><div><div className="eyebrow"><ShieldCheck size={13}/> ACESSO RESTRITO</div><h1>Painel <em>administrativo.</em></h1><p>Operações registradas no Supabase com verificação de permissões.</p></div></div>
    <div className="two-col"><form className="surface" onSubmit={adjust}><div className="section-heading"><h3><Coins size={18}/> Ajustar créditos de teste</h3></div><label>Conta do usuário<select required value={userId} onChange={e=>setUserId(e.target.value)}><option value="">Selecionar treinador</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.display_name} ({a.id.slice(0,8)})</option>)}</select></label><label>Variação de saldo (negativo para débito)<input type="number" required step="1" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="Ex.: 1000 ou -100"/></label><label>Motivo<input maxLength={120} required value={reason} onChange={e=>setReason(e.target.value)}/></label><button className="primary-btn" disabled={busy} type="submit">Registrar ajuste</button></form>
    <form className="surface" onSubmit={schedule}><div className="section-heading"><h3><CalendarDays size={18}/> Criar partida</h3></div><label>Mandante<select required value={home} onChange={e=>setHome(e.target.value)}><option value="">Selecionar</option>{data.clubs.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label><label>Visitante<select required value={away} onChange={e=>setAway(e.target.value)}><option value="">Selecionar</option>{data.clubs.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label><button className="primary-btn" disabled={busy||!data.season} type="submit">Agendar partida</button></form></div>
    <section className="surface"><div className="section-heading"><h3><Activity size={18}/> Jogos pendentes</h3><button className="outline-btn" onClick={reload}><RefreshCw size={14}/> Atualizar</button></div>{data.matches.filter(m=>m.status==='scheduled').length?data.matches.filter(m=>m.status==='scheduled').map(m=><div className="pending-row" key={m.id}><span>{data.clubs.find(c=>c.id===m.home_club_id)?.name} × {data.clubs.find(c=>c.id===m.away_club_id)?.name}</span><button className="outline-btn" onClick={()=>simulate(m.id)} disabled={busy}><Play size={14}/> Simular</button></div>):<p className="muted">Nenhuma partida pendente.</p>}<p className="muted small">A simulação exige 11 atletas válidos e táticas salvas dos dois clubes. O servidor calcula o resultado e o registra uma única vez.</p></section>
  </div>;
}
export default App;
