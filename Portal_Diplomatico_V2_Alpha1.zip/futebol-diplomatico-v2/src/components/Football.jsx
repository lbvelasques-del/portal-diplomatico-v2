import React, { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowLeftRight, Check, ChevronRight, CircleHelp, ClipboardList, Crown, Gauge, LockKeyhole, Play, Save, Shield, ShieldCheck, SlidersHorizontal, Sparkles, Trophy, Users } from 'lucide-react';
import { FORMATIONS, POS_LABELS, autoLineup, fitScore, lineupScore, tierLabel, validateLineup } from '../lib/formations.js';

function ClubMark({ club, size='md' }) {
  const initials=(club?.short_name||club?.name?.split(' ').map(x=>x[0]).join('')||'FC').slice(0,3);
  return <span className={`club-mark ${size}`} style={{'--club-color':club?.primary_color||'#12b981'}}>{initials}</span>;
}
function SmallPill({ children, tone='' }) { return <span className={`small-pill ${tone}`}>{children}</span>; }
const formatTime=d=>{try{return new Date(d).toLocaleDateString('pt-BR',{day:'2-digit',month:'short'});}catch{return '—';}};

export default function Football({clubs,players,matches,standings,season,myClubId,occupied,tactic,onClaim,onSave,onSimulate,isDemo,busy}) {
  const [tab,setTab]=useState('painel');
  const [draft,setDraft]=useState(null);
  const [selectedSlot,setSelectedSlot]=useState(null);
  const [filter,setFilter]=useState('');
  const myClub=clubs.find(x=>x.id===myClubId);
  const tacticVersion=JSON.stringify(tactic||{});
  const myPlayers=useMemo(()=>players.filter(p=>p.club_id===myClubId),[players,myClubId]);
  const defaultTactic=()=>({formation:'4-3-3',style:'Equilibrado',mentality:'Normal',pressure:50,tempo:50,lineup:autoLineup('4-3-3',myPlayers)});
  useEffect(()=>{if(myClubId){setDraft(tactic||defaultTactic());setSelectedSlot(null);}},[myClubId,tacticVersion,myPlayers.length]);
  const formation=draft?.formation||'4-3-3';
  const formationLines=FORMATIONS[formation];
  const score=draft?lineupScore(draft.lineup,myPlayers):0;
  const slotPlayer=slot=>myPlayers.find(p=>p.id===draft?.lineup?.find(x=>x.slot===slot)?.player_id);
  const activeRole=draft?.lineup?.find(x=>x.slot===selectedSlot)?.role;
  const used=new Set((draft?.lineup||[]).filter(x=>x.slot!==selectedSlot).map(x=>x.player_id));
  const candidates=myPlayers.filter(x=>!used.has(x.id)).sort((a,b)=>(b.overall+fitScore(activeRole,b.position))-(a.overall+fitScore(activeRole,a.position)));
  const inTab=(name,content,Icon)=> <button onClick={()=>setTab(name)} className={`subnav-btn ${tab===name?'active':''}`}><Icon size={15}/>{content}</button>;
  function changeFormation(value){setDraft(x=>({...x,formation:value,lineup:autoLineup(value,myPlayers)}));setSelectedSlot(null);}
  function changePlayer(id){setDraft(x=>({...x,lineup:x.lineup.map(e=>e.slot===selectedSlot?{...e,player_id:id}:e)}));}
  function save(){const error=validateLineup(draft.lineup,draft.formation,myPlayers);if(error){alert(error);return;}onSave(draft);}
  const clubById=id=>clubs.find(c=>c.id===id);
  const mine=matches.filter(m=>m.home_club_id===myClubId||m.away_club_id===myClubId);

  return <div className="page-in">
    <div className="page-heading"><div><div className="eyebrow"><Trophy size={13}/> CAMPEONATO • {season?.name||'TEMPORADA'}</div><h1>Futebol <em>Diplomático</em></h1><p>Monte o melhor elenco, prepare suas táticas e enfrente seus amigos.</p></div><SmallPill tone={isDemo?'warn':'good'}>{isDemo?'MODO DEMONSTRAÇÃO':'MULTIPLAYER'}</SmallPill></div>
    {!myClub ? <>
      <div className="hero-strip"><div className="hero-emblem"><ShieldCheck size={32}/></div><div><h2>Escolha seu clube</h2><p>Um treinador por equipe, por temporada. Após a escolha, você poderá montar sua escalação e disputar partidas.</p></div></div>
      <div className="section-heading"><h3>Clubes disponíveis <span>({clubs.length})</span></h3><span className="muted small">{occupied.length} selecionados</span></div>
      <div className="club-grid">{clubs.map(c=>{const taken=occupied.includes(c.id);return <button key={c.id} className={`club-option ${taken?'taken':''}`} onClick={()=>!taken&&onClaim(c.id)} disabled={taken||busy}>
        <ClubMark club={c} size="lg"/><span className="club-option-main"><strong>{c.name}</strong><small>{taken?'Equipe ocupada':'Disponível para assumir'}</small></span>{taken?<LockKeyhole size={15}/>:<ChevronRight size={17}/>}</button>;})}</div>
      <p className="small muted footnote">Os clubes e atletas apresentados nesta primeira versão são fictícios e servem para testes. O banco receberá os dados oficiais somente após conferência e autorização de uso.</p>
    </> : <>
      <div className="club-summary"><ClubMark club={myClub} size="xl"/><div><div className="muted small">SEU CLUBE</div><h2>{myClub.name}</h2><span className="small muted">Contrato de treinador • {season?.name||'Temporada de testes'}</span></div><div className="club-summary-score"><strong>{score||'—'}</strong><span>FORÇA DO XI</span></div></div>
      <div className="subnav">{inTab('painel','Painel',Gauge)}{inTab('taticas','Táticas',SlidersHorizontal)}{inTab('elenco','Elenco',Users)}{inTab('liga','Liga',Trophy)}</div>
      {tab==='painel'&&<div className="stack">
        <div className="stat-grid"><div className="stat-card"><span>Jogadores do elenco</span><strong>{myPlayers.length}</strong><small>Contratos válidos na temporada</small></div><div className="stat-card"><span>Força da escalação</span><strong>{score||'—'}</strong><small>Overall + adaptação posicional</small></div><div className="stat-card"><span>Partidas disputadas</span><strong>{mine.filter(x=>x.status==='played').length}</strong><small>Resultados oficiais registrados</small></div></div>
        <div className="two-col"><section className="surface"><div className="section-heading"><h3><ClipboardList size={18}/> Preparação para a rodada</h3></div><p>Organize seus 11 titulares, ajuste o estilo e salve a escalação. As partidas online são processadas pelo servidor.</p><div className="info-line"><Check size={16}/> {draft?.lineup?.filter(x=>x.player_id).length||0}/11 atletas escalados</div><button className="primary-btn" onClick={()=>setTab('taticas')}>Abrir painel tático <ChevronRight size={16}/></button></section>
        <section className="surface"><div className="section-heading"><h3><Activity size={18}/> Últimos jogos</h3></div>{mine.length?mine.slice(0,4).map(m=><div className="result-row" key={m.id}><span>{clubById(m.home_club_id)?.short_name||'CAS'}</span><b>{m.status==='played'?`${m.home_goals} : ${m.away_goals}`:'VS'}</b><span>{clubById(m.away_club_id)?.short_name||'FOR'}</span><small>{m.status==='played'?'Encerrado':'Agendado'}</small></div>):<div className="empty-state">Ainda não há partidas deste clube.</div>}</section></div>
        {isDemo&&<div className="demo-note"><Sparkles size={17}/><div>Teste local: você pode gerar uma partida de demonstração. Isso não afeta outros jogadores nem possui valor competitivo oficial.</div><button className="outline-btn" onClick={onSimulate}><Play size={14}/> Testar partida</button></div>}
      </div>}
      {tab==='taticas'&&draft&&<div className="tactics-grid">
        <div className="stack"><section className="surface"><div className="section-heading"><h3><SlidersHorizontal size={18}/> Painel do técnico</h3><SmallPill tone="good">ESCALAÇÃO 11/11</SmallPill></div>
          <div className="field-grid"><label>Formação<select value={draft.formation} onChange={e=>changeFormation(e.target.value)}>{Object.keys(FORMATIONS).map(id=><option key={id} value={id}>{id}</option>)}</select></label><label>Estilo<select value={draft.style} onChange={e=>setDraft(x=>({...x,style:e.target.value}))}>{['Equilibrado','Posse de bola','Contra-ataque','Pressão alta','Bolas longas','Jogo pelas pontas'].map(x=><option key={x}>{x}</option>)}</select></label><label>Mentalidade<select value={draft.mentality} onChange={e=>setDraft(x=>({...x,mentality:e.target.value}))}>{['Muito defensiva','Defensiva','Normal','Ofensiva','Tudo ou nada'].map(x=><option key={x}>{x}</option>)}</select></label></div>
          <div className="range-row"><label>Intensidade de pressão <b>{draft.pressure}%</b></label><input type="range" min="0" max="100" step="5" value={draft.pressure} onChange={e=>setDraft(x=>({...x,pressure:Number(e.target.value)}))}/></div>
          <div className="range-row"><label>Ritmo de jogo <b>{draft.tempo}%</b></label><input type="range" min="0" max="100" step="5" value={draft.tempo} onChange={e=>setDraft(x=>({...x,tempo:Number(e.target.value)}))}/></div>
          <button className="primary-btn" onClick={save} disabled={busy}><Save size={16}/>{busy?'Salvando...':'Salvar formação e tática'}</button><p className="muted small">Alterar a formação remonta automaticamente o time. Revise os titulares antes de salvar.</p>
        </section><section className="surface"><div className="section-heading"><h3><Users size={18}/> Escolher jogador</h3></div>
          {selectedSlot? <><p className="small muted">Posição: <b>{POS_LABELS[activeRole]}</b> • Toque em um atleta para colocá-lo em campo.</p><div className="candidate-list">{candidates.map(p=><button className={`candidate ${draft.lineup.find(x=>x.slot===selectedSlot)?.player_id===p.id?'chosen':''}`} key={p.id} onClick={()=>changePlayer(p.id)}><span className={`tier-icon ${p.tier}`}>{p.shirt_number||'•'}</span><span><strong>{p.name}</strong><small>{POS_LABELS[p.position]||p.position} • {tierLabel(p.tier)}</small></span><b>{p.overall}</b></button>)}</div></> : <p className="muted">Toque em um jogador no gramado para alterar sua escalação.</p>}
        </section></div>
        <div className="stack"><section className="surface field-surface"><div className="section-heading"><h3><Shield size={18}/> Campo tático</h3><SmallPill>{formation}</SmallPill></div>
          <div className="pitch"><div className="pitch-midline"/><div className="pitch-circle"/><div className="pitch-box top"/><div className="pitch-box bottom"/>
            <div className="pitch-positions">{formationLines.map((line,row)=><div className="pitch-row" key={row}>{line.map((role,col)=>{const slot=`r${row}s${col}`,p=slotPlayer(slot);return <button key={slot} className={`pitch-player ${selectedSlot===slot?'selected':''}`} onClick={()=>setSelectedSlot(slot)} title={`${POS_LABELS[role]} — ${p?.name||'Vazio'}`}><span className={`pitch-number ${p?.tier||''}`}>{p?.shirt_number||'+'}</span><span className="pitch-name">{p?.name?.split(' ').slice(-1).join(' ')||'Vazio'}</span><small>{POS_LABELS[role]}</small></button>;})}</div>)}</div>
          </div><div className="pitch-footer"><span><Sparkles size={15}/> Força do XI</span><b>{score||'—'} / 99</b></div>
        </section><div className="demo-note"><CircleHelp size={16}/><div>As classes Bronze, Prata, Ouro e Diamante são calculadas pelo overall. A adequação à posição também influencia a força do time.</div></div></div>
      </div>}
      {tab==='elenco'&&<section className="surface"><div className="section-heading"><h3><Users size={18}/> Plantel completo</h3><SmallPill>{myPlayers.length} atletas</SmallPill></div><input placeholder="Pesquisar atleta ou posição..." value={filter} onChange={e=>setFilter(e.target.value)}/><div className="roster-list">{[...myPlayers].filter(p=>p.name.toLowerCase().includes(filter.toLowerCase())||(POS_LABELS[p.position]||p.position).toLowerCase().includes(filter.toLowerCase())).sort((a,b)=>b.overall-a.overall).map(p=><div className="roster-row" key={p.id}><span className={`tier-icon ${p.tier}`}>{p.shirt_number||'•'}</span><span><b>{p.name}</b><small>{POS_LABELS[p.position]} • Contrato de 1 temporada</small></span><SmallPill tone={p.tier}>{tierLabel(p.tier)}</SmallPill><strong>{p.overall}</strong></div>)}</div></section>}
      {tab==='liga'&&<div className="stack"><section className="surface"><div className="section-heading"><h3><Trophy size={18}/> Classificação</h3><SmallPill>3 pontos por vitória</SmallPill></div><div className="table-scroll"><table className="league-table"><thead><tr><th>#</th><th>Clube</th><th>PTS</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th></tr></thead><tbody>{standings.map((s,i)=><tr key={s.club_id} className={s.club_id===myClubId?'is-mine':''}><td>{i+1}</td><td><div className="team-cell"><ClubMark club={clubById(s.club_id)}/><span>{clubById(s.club_id)?.name||s.name}</span></div></td><td><b>{s.points}</b></td><td>{s.played}</td><td>{s.wins}</td><td>{s.draws}</td><td>{s.losses}</td><td>{s.goal_diff}</td></tr>)}</tbody></table></div></section>
      <section className="surface"><div className="section-heading"><h3><ArrowLeftRight size={18}/> Jogos da temporada</h3></div>{matches.length?matches.map(m=><div className="fixture-row" key={m.id}><span className="fixture-date">{formatTime(m.played_at||m.created_at)}</span><span>{clubById(m.home_club_id)?.name||'Casa'}</span><strong>{m.status==='played'?`${m.home_goals} x ${m.away_goals}`:'vs'}</strong><span>{clubById(m.away_club_id)?.name||'Fora'}</span><SmallPill tone={m.status==='played'?'good':''}>{m.status==='played'?'Finalizado':'Pendente'}</SmallPill></div>):<div className="empty-state">O calendário ainda não foi gerado pelo administrador.</div>}</section></div>}
    </>}
  </div>;
}
export { ClubMark, SmallPill };
