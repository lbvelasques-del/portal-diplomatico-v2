-- Portal Diplomático v2 • etapa 1
-- Execute em projeto NOVO do Supabase, pelo SQL Editor. Nunca rode sem backup em banco existente.
-- Esta versão contém apenas créditos recreativos NÃO CONVERSÍVEIS.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Treinador',
  role text not null default 'player' check (role in ('player','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  balance bigint not null default 0 check (balance >= 0),
  updated_at timestamptz not null default now()
);
create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount bigint not null check (amount <> 0),
  balance_after bigint not null check (balance_after >= 0),
  kind text not null check (kind in ('admin_adjustment')),
  reason text not null,
  actor_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index if not exists idx_wallet_ledger_user_date on public.wallet_transactions(user_id,created_at desc);

create table if not exists public.seasons (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  status text not null default 'open' check (status in ('open','active','finished')),
  start_date date not null,
  end_date date not null,
  created_at timestamptz not null default now(),
  check(end_date > start_date)
);
create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  short_name varchar(4) not null,
  primary_color varchar(9) not null default '#20b57e',
  is_demo boolean not null default true
);
create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  position text not null check (position in ('GK','LB','CB','RB','LM','CM','RM','DM','AM','LW','ST','RW')),
  overall int not null check (overall between 50 and 99),
  tier text not null check (tier in ('bronze','silver','gold','diamond')),
  constraint valid_tier_overall check (
    (tier='bronze' and overall between 50 and 69) or
    (tier='silver' and overall between 70 and 79) or
    (tier='gold' and overall between 80 and 89) or
    (tier='diamond' and overall between 90 and 99)),
  shirt_number int check (shirt_number between 1 and 99),
  seeded_club_id uuid references public.clubs(id),
  is_demo boolean not null default true
);
create table if not exists public.player_contracts (
  player_id uuid not null references public.players(id) on delete cascade,
  season_id uuid not null references public.seasons(id) on delete cascade,
  club_id uuid not null references public.clubs(id),
  expires_on date not null,
  primary key (season_id,player_id)
);
create index if not exists idx_pc_season_club on public.player_contracts(season_id,club_id);
create table if not exists public.manager_contracts (
  id uuid primary key default gen_random_uuid(),
  season_id uuid not null references public.seasons(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  club_id uuid not null references public.clubs(id),
  signed_at timestamptz not null default now(),
  expires_on date not null,
  unique(season_id,user_id),
  unique(season_id,club_id)
);
create table if not exists public.formation_positions (
  formation text not null,
  slot text not null,
  role text not null,
  primary key(formation,slot)
);
create table if not exists public.team_tactics (
  season_id uuid not null references public.seasons(id) on delete cascade,
  club_id uuid not null references public.clubs(id),
  formation text not null,
  style text not null,
  mentality text not null,
  pressure int not null check(pressure between 0 and 100),
  tempo int not null check(tempo between 0 and 100),
  lineup jsonb not null,
  updated_at timestamptz not null default now(),
  primary key(season_id,club_id)
);
create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  season_id uuid not null references public.seasons(id) on delete cascade,
  home_club_id uuid not null references public.clubs(id),
  away_club_id uuid not null references public.clubs(id),
  status text not null default 'scheduled' check (status in ('scheduled','played')),
  home_goals int check (home_goals between 0 and 12),
  away_goals int check (away_goals between 0 and 12),
  played_at timestamptz,
  created_at timestamptz not null default now(),
  check(home_club_id <> away_club_id),
  check((status='scheduled' and home_goals is null and away_goals is null)
        or (status='played' and home_goals is not null and away_goals is not null))
);
create index if not exists idx_matches_season_date on public.matches(season_id,created_at desc);

-- Criação automática de conta e carteira sem privilégios de escrita no frontend.
create or replace function public.on_auth_user_created()
returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  insert into public.profiles(id,display_name)
  values(new.id, left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'),''),'Treinador'),36))
  on conflict(id) do nothing;
  insert into public.wallets(user_id,balance) values(new.id,0) on conflict(user_id) do nothing;
  return new;
end; $$;
drop trigger if exists trg_portal_new_user on auth.users;
create trigger trg_portal_new_user after insert on auth.users
for each row execute function public.on_auth_user_created();

-- Executar também para contas criadas antes desta migração.
insert into public.profiles(id,display_name)
select id, left(coalesce(nullif(trim(raw_user_meta_data->>'display_name'),''),'Treinador'),36)
from auth.users on conflict (id) do nothing;
insert into public.wallets(user_id,balance)
select id,0 from auth.users on conflict (user_id) do nothing;

create or replace function public.is_portal_admin()
returns boolean language sql stable security definer set search_path=public,pg_temp as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

-- RLS habilitado em TODAS as tabelas. Nenhuma escrita direta pelo navegador.
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.seasons enable row level security;
alter table public.clubs enable row level security;
alter table public.players enable row level security;
alter table public.player_contracts enable row level security;
alter table public.manager_contracts enable row level security;
alter table public.formation_positions enable row level security;
alter table public.team_tactics enable row level security;
alter table public.matches enable row level security;

create policy profiles_read on public.profiles for select to authenticated using (id=auth.uid() or public.is_portal_admin());
create policy wallets_read on public.wallets for select to authenticated using (user_id=auth.uid() or public.is_portal_admin());
create policy ledger_read on public.wallet_transactions for select to authenticated using (user_id=auth.uid() or public.is_portal_admin());
create policy seasons_read on public.seasons for select to authenticated using (true);
create policy clubs_read on public.clubs for select to authenticated using (true);
create policy players_read on public.players for select to authenticated using (true);
create policy player_contracts_read on public.player_contracts for select to authenticated using (true);
create policy manager_contracts_read on public.manager_contracts for select to authenticated using (true);
create policy formation_positions_read on public.formation_positions for select to authenticated using (true);
create policy team_tactics_read on public.team_tactics for select to authenticated using (
  public.is_portal_admin() or exists(
    select 1 from public.manager_contracts c where c.season_id=team_tactics.season_id
    and c.club_id=team_tactics.club_id and c.user_id=auth.uid()
  )
);
create policy matches_read on public.matches for select to authenticated using (true);

revoke all on public.profiles,public.wallets,public.wallet_transactions,public.seasons,public.clubs,
  public.players,public.player_contracts,public.manager_contracts,public.formation_positions,
  public.team_tactics,public.matches from anon, authenticated;
grant select on public.profiles,public.wallets,public.wallet_transactions,public.seasons,public.clubs,
  public.players,public.player_contracts,public.manager_contracts,public.formation_positions,
  public.team_tactics,public.matches to authenticated;

-- Contrato do técnico: 1 equipe por usuário e 1 usuário por equipe em cada temporada.
create or replace function public.claim_club(p_season_id uuid,p_club_id uuid)
returns void language plpgsql security definer set search_path=public,pg_temp as $$
declare v_end date;
begin
  if auth.uid() is null then raise exception 'Você precisa fazer login.'; end if;
  select end_date into v_end from public.seasons where id=p_season_id and status='open' and end_date>=current_date;
  if not found then raise exception 'Temporada não está aberta para contratações.'; end if;
  if not exists(select 1 from public.clubs where id=p_club_id) then raise exception 'Clube inexistente.'; end if;
  insert into public.manager_contracts(season_id,user_id,club_id,expires_on)
  values(p_season_id,auth.uid(),p_club_id,v_end);
exception
  when unique_violation then raise exception 'Você ou este clube já possui contrato nesta temporada.';
end; $$;

-- Salva tática somente se TODOS os 11 atletas pertencem ao clube naquela temporada.
create or replace function public.save_tactics(
  p_season_id uuid,p_formation text,p_style text,p_mentality text,
  p_pressure integer,p_tempo integer,p_lineup jsonb
) returns void language plpgsql security definer set search_path=public,pg_temp as $$
declare v_club uuid; v_count int; v_unique_slots int; v_unique_players int; v_matched int; v_eligible int; v_gk int;
begin
  if auth.uid() is null then raise exception 'Autenticação necessária.'; end if;
  select mc.club_id into v_club from public.manager_contracts mc
  join public.seasons s on s.id=mc.season_id
  where mc.season_id=p_season_id and mc.user_id=auth.uid()
    and s.status in ('open','active') and mc.expires_on>=current_date;
  if v_club is null then raise exception 'Não há contrato válido para esta temporada.'; end if;
  if not exists(select 1 from public.formation_positions where formation=p_formation) then
    raise exception 'Formação inexistente.';
  end if;
  if p_style not in ('Equilibrado','Posse de bola','Contra-ataque','Pressão alta','Bolas longas','Jogo pelas pontas')
     or p_mentality not in ('Muito defensiva','Defensiva','Normal','Ofensiva','Tudo ou nada')
     or p_pressure not between 0 and 100 or p_tempo not between 0 and 100 then
    raise exception 'Opções táticas inválidas.';
  end if;
  if jsonb_typeof(p_lineup)<>'array' or jsonb_array_length(p_lineup)<>11 then
    raise exception 'É obrigatório escalar 11 jogadores.';
  end if;
  select count(*),count(distinct x.entry->>'slot'),count(distinct x.entry->>'player_id'),
         count(fp.slot),count(pc.player_id),
         count(*) filter(where (fp.role='GK') = (p.position='GK'))
  into v_count,v_unique_slots,v_unique_players,v_matched,v_eligible,v_gk
  from jsonb_array_elements(p_lineup) x(entry)
  left join public.formation_positions fp on fp.formation=p_formation
    and fp.slot=x.entry->>'slot' and fp.role=x.entry->>'role'
  left join public.player_contracts pc on pc.season_id=p_season_id and pc.club_id=v_club
    and pc.expires_on>=current_date and pc.expires_on>=current_date and pc.player_id=(x.entry->>'player_id')::uuid
  left join public.players p on p.id=pc.player_id;
  if v_count<>11 or v_unique_slots<>11 or v_unique_players<>11 or v_matched<>11 or v_eligible<>11 or v_gk<>11 then
    raise exception 'Escalação inválida: confira posições e contratos.';
  end if;
  insert into public.team_tactics(season_id,club_id,formation,style,mentality,pressure,tempo,lineup,updated_at)
  values(p_season_id,v_club,p_formation,p_style,p_mentality,p_pressure,p_tempo,p_lineup,now())
  on conflict(season_id,club_id) do update set
    formation=excluded.formation,style=excluded.style,mentality=excluded.mentality,
    pressure=excluded.pressure,tempo=excluded.tempo,lineup=excluded.lineup,updated_at=now();
end; $$;

-- Créditos de TESTE: ajustes somente por administrador, com operação atômica e histórico.
create or replace function public.admin_adjust_balance(p_target_user uuid,p_delta bigint,p_reason text)
returns bigint language plpgsql security definer set search_path=public,pg_temp as $$
declare v_balance bigint;
begin
  if not public.is_portal_admin() then raise exception 'Permissão negada.'; end if;
  if p_delta=0 or p_delta not between -10000000 and 10000000 then raise exception 'Variação inválida (limite 10 milhões por operação).'; end if;
  if length(trim(coalesce(p_reason,''))) not between 3 and 120 then raise exception 'Informe um motivo válido.'; end if;
  update public.wallets set balance=balance+p_delta,updated_at=now()
  where user_id=p_target_user and balance+p_delta>=0 returning balance into v_balance;
  if not found then raise exception 'Usuário inexistente ou saldo insuficiente.'; end if;
  insert into public.wallet_transactions(user_id,amount,balance_after,kind,reason,actor_id)
  values(p_target_user,p_delta,v_balance,'admin_adjustment',trim(p_reason),auth.uid());
  return v_balance;
end; $$;

-- Agendamento e partidas via RPC, nunca por atualização direta no navegador.
create or replace function public.admin_schedule_match(p_season_id uuid,p_home_club uuid,p_away_club uuid)
returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare v_id uuid;
begin
  if not public.is_portal_admin() then raise exception 'Permissão negada.'; end if;
  if p_home_club=p_away_club then raise exception 'Escolha equipes diferentes.'; end if;
  if not exists(select 1 from public.seasons where id=p_season_id and status in ('open','active')) then raise exception 'Temporada inválida.'; end if;
  if not exists(select 1 from public.manager_contracts where season_id=p_season_id and club_id=p_home_club)
    or not exists(select 1 from public.manager_contracts where season_id=p_season_id and club_id=p_away_club) then
    raise exception 'Ambos os clubes precisam ter treinadores contratados.';
  end if;
  insert into public.matches(season_id,home_club_id,away_club_id)
  values(p_season_id,p_home_club,p_away_club) returning id into v_id;
  return v_id;
end; $$;

-- Força por XI: overall, classe, adequação à posição e intensidade tática.
create or replace function public.match_team_power(p_season_id uuid,p_club_id uuid)
returns numeric language plpgsql stable security definer set search_path=public,pg_temp as $$
declare v_t public.team_tactics%rowtype; v_score numeric; v_count integer;
begin
  select * into v_t from public.team_tactics where season_id=p_season_id and club_id=p_club_id;
  if not found then raise exception 'Um dos clubes não possui tática salva.'; end if;
  select count(*),avg(
     p.overall
     + case p.tier when 'diamond' then 3 when 'gold' then 1.5 when 'silver' then .5 else 0 end
     + case when p.position=x.entry->>'role' then 5
            when p.position='GK' or x.entry->>'role'='GK' then -40
            when p.position in ('LB','RB','CB') and x.entry->>'role' in ('LB','RB','CB') then -2
            when p.position in ('DM','CM','AM','LM','RM') and x.entry->>'role' in ('DM','CM','AM','LM','RM') then -3
            when p.position in ('LW','RW','ST') and x.entry->>'role' in ('LW','RW','ST') then -3
            else -12 end
  ) into v_count,v_score
  from jsonb_array_elements(v_t.lineup) x(entry)
  join public.player_contracts pc on pc.season_id=p_season_id and pc.club_id=p_club_id
    and pc.expires_on>=current_date and pc.expires_on>=current_date and pc.player_id=(x.entry->>'player_id')::uuid
  join public.players p on p.id=pc.player_id;
  if v_count<>11 then raise exception 'Escalação de um dos clubes está incompleta.'; end if;
  return v_score - abs(v_t.pressure-60)*.025 - abs(v_t.tempo-55)*.025
    + case v_t.mentality when 'Ofensiva' then .5 when 'Defensiva' then .5 else 0 end;
end; $$;

create or replace function public.match_draw_goals(p_expected numeric)
returns integer language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare v_lambda numeric:=greatest(.18,least(4.1,p_expected)); v_bound float8; v_product float8:=1; v_goals int:=0;
begin
  v_bound:=exp(-v_lambda);
  loop
    v_product:=v_product*random();
    exit when v_product<=v_bound or v_goals>=11;
    v_goals:=v_goals+1;
  end loop;
  return v_goals;
end; $$;

create or replace function public.admin_simulate_match(p_match_id uuid)
returns table(home_goals int,away_goals int) language plpgsql security definer set search_path=public,pg_temp as $$
declare v_match public.matches%rowtype; v_h numeric; v_a numeric; v_style_h text; v_style_a text;
        v_exp_h numeric; v_exp_a numeric; v_hg int; v_ag int;
begin
  if not public.is_portal_admin() then raise exception 'Permissão negada.'; end if;
  select * into v_match from public.matches where id=p_match_id for update;
  if not found then raise exception 'Partida inexistente.'; end if;
  if v_match.status<>'scheduled' then raise exception 'Partida já encerrada.'; end if;
  v_h:=public.match_team_power(v_match.season_id,v_match.home_club_id);
  v_a:=public.match_team_power(v_match.season_id,v_match.away_club_id);
  select style into v_style_h from public.team_tactics where season_id=v_match.season_id and club_id=v_match.home_club_id;
  select style into v_style_a from public.team_tactics where season_id=v_match.season_id and club_id=v_match.away_club_id;
  v_exp_h:=1.42+(v_h-v_a)/24+.12;
  v_exp_a:=1.29+(v_a-v_h)/24;
  if v_style_h='Contra-ataque' and v_style_a='Pressão alta' then v_exp_h:=v_exp_h+.28; end if;
  if v_style_a='Contra-ataque' and v_style_h='Pressão alta' then v_exp_a:=v_exp_a+.28; end if;
  v_hg:=public.match_draw_goals(v_exp_h);v_ag:=public.match_draw_goals(v_exp_a);
  update public.matches m set status='played',home_goals=v_hg,away_goals=v_ag,played_at=now() where m.id=p_match_id;
  return query select v_hg,v_ag;
end; $$;

-- Não expor funções internas à chamada direta por usuários autenticados.
revoke all on function public.on_auth_user_created() from public,anon,authenticated;
revoke all on function public.is_portal_admin() from public,anon;
revoke all on function public.claim_club(uuid,uuid) from public,anon;
revoke all on function public.save_tactics(uuid,text,text,text,integer,integer,jsonb) from public,anon;
revoke all on function public.admin_adjust_balance(uuid,bigint,text) from public,anon;
revoke all on function public.admin_schedule_match(uuid,uuid,uuid) from public,anon;
revoke all on function public.admin_simulate_match(uuid) from public,anon;
revoke all on function public.match_team_power(uuid,uuid) from public,anon,authenticated;
revoke all on function public.match_draw_goals(numeric) from public,anon,authenticated;
grant execute on function public.is_portal_admin() to authenticated;
grant execute on function public.claim_club(uuid,uuid) to authenticated;
grant execute on function public.save_tactics(uuid,text,text,text,integer,integer,jsonb) to authenticated;
grant execute on function public.admin_adjust_balance(uuid,bigint,text) to authenticated;
grant execute on function public.admin_schedule_match(uuid,uuid,uuid) to authenticated;
grant execute on function public.admin_simulate_match(uuid) to authenticated;

-- Seeds de demonstração: NENHUM clube ou atleta abaixo é declarado oficial.
insert into public.seasons(name,status,start_date,end_date)
values('Temporada de testes','open',current_date,(current_date+interval '365 days')::date)
on conflict(name) do nothing;

insert into public.clubs(name,short_name,primary_color,is_demo) values
('Atlético Aurora','AUR','#17a973',true),('Costa do Sol FC','CSF','#f6b94a',true),
('União Serrana','USR','#5e9df6',true),('Nacional do Vale','NDV','#e56f7b',true),
('Ferroviário Central','FEC','#a988ea',true),('Estrela Azul','EAZ','#17a973',true),
('Pampas Atlético','PAT','#f6b94a',true),('Fênix Esporte Clube','FEC','#5e9df6',true),
('Marítimo do Norte','MDN','#e56f7b',true),('Bandeirantes FC','BFC','#a988ea',true),
('Real Horizonte','RHO','#17a973',true),('Grêmio do Litoral','GDL','#f6b94a',true),
('Olímpico Verde','OVD','#5e9df6',true),('Vila Imperial','VIM','#e56f7b',true),
('Sporting Capital','SCA','#a988ea',true),('Monte Azul','MAZ','#17a973',true),
('Atlético Continental','ACO','#f6b94a',true),('Nova Era FC','NEF','#5e9df6',true),
('União dos Campos','UDC','#e56f7b',true),('Racing Colonial','RCO','#a988ea',true)
on conflict(name) do nothing;

with generated as (
  select c.id as club_id, dense_rank() over(order by c.name) as ci,
    pos.pos, pos.ord from public.clubs c
  cross join lateral unnest(array[
    'GK','GK','GK','LB','LB','RB','RB','CB','CB','CB','CB','DM','DM','CM','CM','CM','LM','RM','AM','LW','RW','ST','ST'
  ]::text[]) with ordinality as pos(pos,ord)
  where c.is_demo=true
), roster as (
  select club_id,ci,pos,ord,59+mod((ci*11+ord*7+mod(ord*ord,15))::int,35) as overall from generated
)
insert into public.players(name,position,overall,tier,shirt_number,seeded_club_id,is_demo)
select 'Atleta '||lpad(ci::text,2,'0')||'-'||lpad(ord::text,2,'0'),pos,overall,
  case when overall>=90 then 'diamond' when overall>=80 then 'gold'
    when overall>=70 then 'silver' else 'bronze' end,
  ord,club_id,true from roster
where not exists (select 1 from public.players where is_demo=true and seeded_club_id=roster.club_id and shirt_number=roster.ord);

insert into public.player_contracts(player_id,season_id,club_id,expires_on)
select p.id,s.id,p.seeded_club_id,s.end_date from public.players p
cross join public.seasons s
where p.is_demo=true and p.seeded_club_id is not null and s.name='Temporada de testes'
on conflict(season_id,player_id) do nothing;

-- Tabela classificatória calculada das partidas registradas; não é editável pelo cliente.
create or replace view public.standings with (security_invoker=true) as
with per_match as (
  select season_id,home_club_id as club_id,1 as played,
    (home_goals>away_goals)::int as wins,(home_goals=away_goals)::int as draws,
    (home_goals<away_goals)::int as losses, home_goals as gf,away_goals as ga,
    case when home_goals>away_goals then 3 when home_goals=away_goals then 1 else 0 end as pts
    from public.matches where status='played'
  union all
  select season_id,away_club_id as club_id,1,
    (away_goals>home_goals)::int,(away_goals=home_goals)::int,(away_goals<home_goals)::int,
    away_goals,home_goals,
    case when away_goals>home_goals then 3 when away_goals=home_goals then 1 else 0 end
    from public.matches where status='played'
)
select s.id as season_id,c.id as club_id,c.name,
  coalesce(sum(m.played),0)::int as played,coalesce(sum(m.wins),0)::int as wins,
  coalesce(sum(m.draws),0)::int as draws,coalesce(sum(m.losses),0)::int as losses,
  coalesce(sum(m.gf),0)::int as goals_for,coalesce(sum(m.ga),0)::int as goals_against,
  (coalesce(sum(m.gf),0)-coalesce(sum(m.ga),0))::int as goal_diff,
  coalesce(sum(m.pts),0)::int as points
from public.seasons s cross join public.clubs c
left join per_match m on m.season_id=s.id and m.club_id=c.id
group by s.id,c.id,c.name;
revoke all on public.standings from public,anon,authenticated;
grant select on public.standings to authenticated;

-- CONCEDA ADMIN MANUALMENTE depois do cadastro, no SQL Editor (nunca no frontend):
-- update public.profiles set role='admin' where id=(select id from auth.users where email='seu@email.com');

-- Cadastro das 16 formações e suas onze posições.
insert into public.formation_positions(formation,slot,role) values
('4-3-3','r0s0','LW'),
('4-3-3','r0s1','ST'),
('4-3-3','r0s2','RW'),
('4-3-3','r1s0','CM'),
('4-3-3','r1s1','DM'),
('4-3-3','r1s2','CM'),
('4-3-3','r2s0','LB'),
('4-3-3','r2s1','CB'),
('4-3-3','r2s2','CB'),
('4-3-3','r2s3','RB'),
('4-3-3','r3s0','GK'),
('4-4-2','r0s0','ST'),
('4-4-2','r0s1','ST'),
('4-4-2','r1s0','LM'),
('4-4-2','r1s1','CM'),
('4-4-2','r1s2','CM'),
('4-4-2','r1s3','RM'),
('4-4-2','r2s0','LB'),
('4-4-2','r2s1','CB'),
('4-4-2','r2s2','CB'),
('4-4-2','r2s3','RB'),
('4-4-2','r3s0','GK'),
('4-2-3-1','r0s0','ST'),
('4-2-3-1','r1s0','LW'),
('4-2-3-1','r1s1','AM'),
('4-2-3-1','r1s2','RW'),
('4-2-3-1','r2s0','DM'),
('4-2-3-1','r2s1','DM'),
('4-2-3-1','r3s0','LB'),
('4-2-3-1','r3s1','CB'),
('4-2-3-1','r3s2','CB'),
('4-2-3-1','r3s3','RB'),
('4-2-3-1','r4s0','GK'),
('4-1-4-1','r0s0','ST'),
('4-1-4-1','r1s0','LM'),
('4-1-4-1','r1s1','CM'),
('4-1-4-1','r1s2','CM'),
('4-1-4-1','r1s3','RM'),
('4-1-4-1','r2s0','DM'),
('4-1-4-1','r3s0','LB'),
('4-1-4-1','r3s1','CB'),
('4-1-4-1','r3s2','CB'),
('4-1-4-1','r3s3','RB'),
('4-1-4-1','r4s0','GK'),
('4-3-1-2','r0s0','ST'),
('4-3-1-2','r0s1','ST'),
('4-3-1-2','r1s0','AM'),
('4-3-1-2','r2s0','CM'),
('4-3-1-2','r2s1','DM'),
('4-3-1-2','r2s2','CM'),
('4-3-1-2','r3s0','LB'),
('4-3-1-2','r3s1','CB'),
('4-3-1-2','r3s2','CB'),
('4-3-1-2','r3s3','RB'),
('4-3-1-2','r4s0','GK'),
('4-2-2-2','r0s0','ST'),
('4-2-2-2','r0s1','ST'),
('4-2-2-2','r1s0','AM'),
('4-2-2-2','r1s1','AM'),
('4-2-2-2','r2s0','DM'),
('4-2-2-2','r2s1','DM'),
('4-2-2-2','r3s0','LB'),
('4-2-2-2','r3s1','CB'),
('4-2-2-2','r3s2','CB'),
('4-2-2-2','r3s3','RB'),
('4-2-2-2','r4s0','GK'),
('4-5-1','r0s0','ST'),
('4-5-1','r1s0','LM'),
('4-5-1','r1s1','CM'),
('4-5-1','r1s2','DM'),
('4-5-1','r1s3','CM'),
('4-5-1','r1s4','RM'),
('4-5-1','r2s0','LB'),
('4-5-1','r2s1','CB'),
('4-5-1','r2s2','CB'),
('4-5-1','r2s3','RB'),
('4-5-1','r3s0','GK'),
('4-2-4','r0s0','LW'),
('4-2-4','r0s1','ST'),
('4-2-4','r0s2','ST'),
('4-2-4','r0s3','RW'),
('4-2-4','r1s0','DM'),
('4-2-4','r1s1','DM'),
('4-2-4','r2s0','LB'),
('4-2-4','r2s1','CB'),
('4-2-4','r2s2','CB'),
('4-2-4','r2s3','RB'),
('4-2-4','r3s0','GK'),
('4-1-2-1-2','r0s0','ST'),
('4-1-2-1-2','r0s1','ST'),
('4-1-2-1-2','r1s0','AM'),
('4-1-2-1-2','r2s0','CM'),
('4-1-2-1-2','r2s1','CM'),
('4-1-2-1-2','r3s0','DM'),
('4-1-2-1-2','r4s0','LB'),
('4-1-2-1-2','r4s1','CB'),
('4-1-2-1-2','r4s2','CB'),
('4-1-2-1-2','r4s3','RB'),
('4-1-2-1-2','r5s0','GK'),
('3-5-2','r0s0','ST'),
('3-5-2','r0s1','ST'),
('3-5-2','r1s0','LM'),
('3-5-2','r1s1','CM'),
('3-5-2','r1s2','DM'),
('3-5-2','r1s3','CM'),
('3-5-2','r1s4','RM'),
('3-5-2','r2s0','CB'),
('3-5-2','r2s1','CB'),
('3-5-2','r2s2','CB'),
('3-5-2','r3s0','GK'),
('3-4-3','r0s0','LW'),
('3-4-3','r0s1','ST'),
('3-4-3','r0s2','RW'),
('3-4-3','r1s0','LM'),
('3-4-3','r1s1','CM'),
('3-4-3','r1s2','CM'),
('3-4-3','r1s3','RM'),
('3-4-3','r2s0','CB'),
('3-4-3','r2s1','CB'),
('3-4-3','r2s2','CB'),
('3-4-3','r3s0','GK'),
('3-4-2-1','r0s0','ST'),
('3-4-2-1','r1s0','AM'),
('3-4-2-1','r1s1','AM'),
('3-4-2-1','r2s0','LM'),
('3-4-2-1','r2s1','CM'),
('3-4-2-1','r2s2','CM'),
('3-4-2-1','r2s3','RM'),
('3-4-2-1','r3s0','CB'),
('3-4-2-1','r3s1','CB'),
('3-4-2-1','r3s2','CB'),
('3-4-2-1','r4s0','GK'),
('3-6-1','r0s0','ST'),
('3-6-1','r1s0','AM'),
('3-6-1','r1s1','AM'),
('3-6-1','r2s0','LM'),
('3-6-1','r2s1','CM'),
('3-6-1','r2s2','CM'),
('3-6-1','r2s3','RM'),
('3-6-1','r3s0','CB'),
('3-6-1','r3s1','CB'),
('3-6-1','r3s2','CB'),
('3-6-1','r4s0','GK'),
('5-3-2','r0s0','ST'),
('5-3-2','r0s1','ST'),
('5-3-2','r1s0','CM'),
('5-3-2','r1s1','DM'),
('5-3-2','r1s2','CM'),
('5-3-2','r2s0','LB'),
('5-3-2','r2s1','CB'),
('5-3-2','r2s2','CB'),
('5-3-2','r2s3','CB'),
('5-3-2','r2s4','RB'),
('5-3-2','r3s0','GK'),
('5-4-1','r0s0','ST'),
('5-4-1','r1s0','LM'),
('5-4-1','r1s1','CM'),
('5-4-1','r1s2','CM'),
('5-4-1','r1s3','RM'),
('5-4-1','r2s0','LB'),
('5-4-1','r2s1','CB'),
('5-4-1','r2s2','CB'),
('5-4-1','r2s3','CB'),
('5-4-1','r2s4','RB'),
('5-4-1','r3s0','GK'),
('5-2-3','r0s0','LW'),
('5-2-3','r0s1','ST'),
('5-2-3','r0s2','RW'),
('5-2-3','r1s0','CM'),
('5-2-3','r1s1','CM'),
('5-2-3','r2s0','LB'),
('5-2-3','r2s1','CB'),
('5-2-3','r2s2','CB'),
('5-2-3','r2s3','CB'),
('5-2-3','r2s4','RB'),
('5-2-3','r3s0','GK')
on conflict(formation,slot) do nothing;
