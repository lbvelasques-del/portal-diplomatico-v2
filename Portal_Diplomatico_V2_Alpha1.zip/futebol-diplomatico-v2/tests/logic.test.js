import test from 'node:test';
import assert from 'node:assert/strict';
import { FORMATIONS, autoLineup, lineupScore, validateLineup, tierOf, slotsForFormation } from '../src/lib/formations.js';
import { demoClubs, demoPlayers, demoStandings } from '../src/lib/demo.js';

const roster=demoPlayers.filter(p=>p.club_id===demoClubs[0].id);

test('temporada de testes contém 20 clubes e 23 atletas por clube',()=>{
  assert.equal(demoClubs.length,20);
  assert.equal(demoPlayers.length,460);
  for(const club of demoClubs)assert.equal(demoPlayers.filter(p=>p.club_id===club.id).length,23);
});
test('as 16 formações têm exatamente 11 posições únicas',()=>{
  assert.equal(Object.keys(FORMATIONS).length,16);
  for(const formation of Object.keys(FORMATIONS)){
    const slots=slotsForFormation(formation);
    assert.equal(slots.length,11,formation);
    assert.equal(new Set(slots.map(s=>s.slot)).size,11,formation);
    assert.equal(slots.filter(s=>s.role==='GK').length,1,formation);
  }
});
test('escalação automática usa 11 atletas elegíveis e nenhum duplicado',()=>{
  for(const formation of Object.keys(FORMATIONS)){
    const lineup=autoLineup(formation,roster);
    assert.equal(validateLineup(lineup,formation,roster),'',formation);
    assert.ok(lineupScore(lineup,roster)>0);
  }
});
test('validação recusa duplicidade e jogadores fora do elenco',()=>{
  const lineup=autoLineup('4-3-3',roster);
  const duplicated=lineup.map(x=>({...x}));duplicated[1].player_id=duplicated[0].player_id;
  assert.match(validateLineup(duplicated,'4-3-3',roster),/duas posições/);
  const foreign=lineup.map(x=>({...x}));foreign[1].player_id=demoPlayers.find(p=>p.club_id!==roster[0].club_id).id;
  assert.match(validateLineup(foreign,'4-3-3',roster),/fora do seu elenco/);
});
test('categorias respeitam faixas do overall',()=>{
  assert.equal(tierOf(55),'bronze');assert.equal(tierOf(70),'silver');
  assert.equal(tierOf(80),'gold');assert.equal(tierOf(90),'diamond');
});
test('classificação soma vitórias, empates, gols e saldo',()=>{
  const home=demoClubs[0].id,away=demoClubs[1].id;
  const table=demoStandings([{id:'1',status:'played',home_club_id:home,away_club_id:away,home_goals:2,away_goals:1}]);
  assert.equal(table.find(c=>c.club_id===home).points,3);
  assert.equal(table.find(c=>c.club_id===home).goal_diff,1);
  assert.equal(table.find(c=>c.club_id===away).losses,1);
});
